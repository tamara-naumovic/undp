function prikazi() {
  var x = document.getElementById("pregled");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}




$('#btnDodaj').submit(function () {
  $('myModal').modal('toggle');
  return false;
});

$('#btn-izmeni').submit(function () {

  $('#myModal').modal('toggle');
  return false;
});

